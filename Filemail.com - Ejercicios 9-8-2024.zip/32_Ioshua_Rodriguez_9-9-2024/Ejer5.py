n1=int(input("Ingrese Numero: "))
n2=int(input("Ingrese Numero: "))
n3=int(input("Ingrese Numero: "))
if n1<10 or n2<10 or n3<10:
    print("Alguno de los numeros es menor a 10")
